public enum ID {
    enemy,
    tekst,
    player,
    mangija1,
    player2;
}
